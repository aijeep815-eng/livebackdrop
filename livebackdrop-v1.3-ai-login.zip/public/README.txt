Place your image assets here:
- /public/logo.png (use the rounded LB logo)
- /public/home-hero.png (use the homepage mockup image)
