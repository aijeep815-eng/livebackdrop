import Nav from '../components/Nav'
import Footer from '../components/Footer'
export default function About(){
  return (<div><Nav/><main className="container"><h1>About</h1><p>LiveBackdrop helps creators design AI backgrounds for live streams.</p></main><Footer/></div>)
}
