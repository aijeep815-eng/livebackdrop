import Nav from '../components/Nav'
import Footer from '../components/Footer'
export default function Pricing(){
  return (<div><Nav/><main className="container"><h1>Pricing</h1><ul><li>Free - basic backgrounds</li><li>Pro - $9.99/month for HD + AI styles</li></ul></main><Footer/></div>)
}
